class ProductData {

  final String url;
  final String name;
  final double price;
  final String imageurl;
  final int reviews;
  final double rating;

  ProductData({this.imageurl,this.name, this.price,this.rating,this.reviews,this.url});

}